"""
Test goes here

"""

from mylib.calculator import add


def test_add():
    assert add(1, 2) == 3
